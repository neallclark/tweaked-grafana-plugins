declare var DruidDatasource: any;
export {DruidDatasource};

