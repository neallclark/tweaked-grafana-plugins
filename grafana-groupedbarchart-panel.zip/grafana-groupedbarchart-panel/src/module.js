import {GroupedBarChartCtrl} from './ctrl';

export {
    GroupedBarChartCtrl as PanelCtrl
};